import IngoSCostTransparency from './ingo-s-cost-transparency/ingo-s-cost-transparency.js';
// Import other plugins if necessary
// Register your plugin via the existing PluginManager
const PluginManager = window.PluginManager;
PluginManager.register('IngoSCostTransparency', IngoSCostTransparency);
