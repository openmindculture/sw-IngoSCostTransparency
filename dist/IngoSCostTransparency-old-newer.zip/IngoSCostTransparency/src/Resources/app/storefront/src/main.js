import IngoSCostTransparency from './ingo-s-cost-transparency/ingo-s-cost-transparency.js';

const PluginManager = window.PluginManager;
PluginManager.register('IngoSCostTransparency', IngoSCostTransparency);
